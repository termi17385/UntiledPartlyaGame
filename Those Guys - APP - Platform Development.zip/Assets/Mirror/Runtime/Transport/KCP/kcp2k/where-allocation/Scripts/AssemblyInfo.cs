using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("where-allocations.Tests")]