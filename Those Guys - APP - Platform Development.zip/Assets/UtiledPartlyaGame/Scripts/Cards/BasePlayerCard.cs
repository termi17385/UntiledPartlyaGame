using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// todo: rename the file name to match the script name when inheriting
[CreateAssetMenu(fileName = "PlayerCard", menuName = "Cards/Player")]
public class BasePlayerCard : BaseCard
{
	// todo: setup this card then inherit from it for different types
}
