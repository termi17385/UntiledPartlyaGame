using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// todo: rename the file name to match the script name when inheriting
[CreateAssetMenu(fileName = "MatchCard", menuName = "Cards/Match")]
public class BaseMatchCard : BaseCard
{
	// todo: setup this card then inherit from it for different types
}
