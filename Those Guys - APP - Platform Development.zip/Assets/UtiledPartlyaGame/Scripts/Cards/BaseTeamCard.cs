using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// todo: rename the file name to match the script name when inheriting
[CreateAssetMenu(fileName = "TeamCard", menuName = "Cards/Team")]
public class BaseTeamCard : BaseCard
{
	// todo: setup this card then inherit from it for different types
}
